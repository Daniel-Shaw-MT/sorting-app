import React from 'react';
import { InputSelector } from './components/InputSelector';
import './main.css'



function App() {
  return (
    <div className="App">
      <div className='container-min'>
      <h1>Welcome</h1>
      </div>
      <br></br>
      <InputSelector />
      
    </div>
  );
}

export default App;
