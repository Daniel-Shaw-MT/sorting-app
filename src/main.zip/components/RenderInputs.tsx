// Calculates and renders array in order specified

import React from 'react'

// Passes in the numbers array
interface Props {
    numbers: number[];
}

export const RenderInputs: React.FC<Props> = ({
    numbers
}) => {

    // Sorts numbers in an ascending fashion
    const orderAsc = () => {
        let numbersAsc = numbers.sort((a, b) => a < b ? -1 : a > b ? 1 : 0)
        console.log(numbersAsc)
        renderArr(numbersAsc)
    }

    // Sorts numbers in a descending fashion
    const orderDesc = () => {
        let numbersDsc = numbers.sort((a, b) => a < b ? 1 : a > b ? -1 : 0)
        console.log(numbersDsc)
        renderArr(numbersDsc);
    }

    // Renders items in list format
    const renderArr = (arr: number[]) => {
        let listItems = arr.map((number) =>
        <li>{number}</li>
        );
    }


    return (
        <div>
            <h1>List View</h1>
        <button onClick={orderAsc}>Order in Ascending</button>   
        <button onClick={orderDesc}>Order in Descending</button>
    
        </div>
    )
}


